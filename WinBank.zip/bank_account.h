#pragma once
#include <string>
class bank_account
{
public:
	std::string first_name;
	std::string last_name;
	std::string email;
	std::string password;
	std::string id_number;
	std::string afm;
	std::string birth_date;
	std::string full_iban;
	std::string short_iban;
	std::string card1_number;
	std::string card2_number;
	long float balance;
	bool remember;
	
	int income;
	
	bank_account();
	
};

