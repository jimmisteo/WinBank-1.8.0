#pragma once
#include "bank_account.h"
class moneybox :public bank_account
{
public:
	std::string box_name;
	long float goal;
	long float saved;
	char end_date[8];
	std::string category;
	moneybox();
};

